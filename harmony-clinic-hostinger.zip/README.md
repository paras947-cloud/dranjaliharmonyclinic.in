# Harmony Clinic — Hostinger Node.js package

This ZIP is a self-contained production package. The React/Vite website has
already been built into `dist/`; the deployed Node.js server only serves those
production files. It has no runtime npm dependencies.

## Deploy through Hostinger hPanel

1. In Hostinger, open **Websites → Create Website → Web App** and choose
   **Upload your website files**.
2. Upload the ZIP without unpacking or renaming its contents.
3. If Hostinger asks you to choose a framework, select **Other**.
4. Use these settings if Hostinger does not detect them automatically:

   | Setting | Value |
   | --- | --- |
   | Node.js version | 22.x (or another version supported by Hostinger) |
   | Build command | `npm run build` |
   | Output directory | `dist` |
   | Entry file | `app.js` |
   | Start command | `npm start` |

5. Deploy the app and open its domain to confirm the site loads.

The app listens on Hostinger's `PORT` environment variable and binds to
`0.0.0.0`. `/health` returns a small JSON health check.

## Local test

From the extracted package folder, run:

```sh
npm run build
npm start
```

Then open `http://localhost:3000`. The static site files in `dist/` must stay
next to `app.js`.

## VPS note

Hostinger VPS plans use manual Node.js setup rather than the hPanel Web App
upload flow. Extract this package on the VPS, install a supported Node.js
version, and run it with a process manager or reverse proxy configured for
`npm start`.
