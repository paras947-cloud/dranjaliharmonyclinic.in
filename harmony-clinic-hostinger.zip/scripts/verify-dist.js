const fs = require("node:fs");
const path = require("node:path");

const distDir = path.resolve(__dirname, "..", "dist");
const indexPath = path.join(distDir, "index.html");
const assetsDir = path.join(distDir, "assets");

if (!fs.existsSync(indexPath) || !fs.statSync(indexPath).isFile()) {
  throw new Error("Production build is missing: dist/index.html");
}

if (!fs.existsSync(assetsDir) || !fs.statSync(assetsDir).isDirectory()) {
  throw new Error("Production build is missing: dist/assets/");
}

console.log("Production site files found in dist/.");
