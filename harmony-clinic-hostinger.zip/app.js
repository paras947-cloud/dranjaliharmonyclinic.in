const fs = require("node:fs");
const http = require("node:http");
const path = require("node:path");

const DIST_DIR = path.resolve(__dirname, "dist");
const MIME_TYPES = {
  ".css": "text/css; charset=utf-8",
  ".gif": "image/gif",
  ".html": "text/html; charset=utf-8",
  ".ico": "image/x-icon",
  ".jpeg": "image/jpeg",
  ".jpg": "image/jpeg",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".robots": "text/plain; charset=utf-8",
  ".svg": "image/svg+xml",
  ".txt": "text/plain; charset=utf-8",
  ".webp": "image/webp",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
};

function sendText(response, statusCode, message, extraHeaders = {}) {
  response.writeHead(statusCode, {
    "Cache-Control": "no-store",
    "Content-Type": "text/plain; charset=utf-8",
    "X-Content-Type-Options": "nosniff",
    ...extraHeaders,
  });
  response.end(message);
}

function setSecurityHeaders(response) {
  response.setHeader("X-Content-Type-Options", "nosniff");
  response.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  response.setHeader("X-Frame-Options", "SAMEORIGIN");
}

async function resolveRequestFile(pathname) {
  const decodedPath = decodeURIComponent(pathname);
  const candidate = path.resolve(DIST_DIR, `.${decodedPath}`);
  const relativePath = path.relative(DIST_DIR, candidate);

  if (
    relativePath === ".." ||
    relativePath.startsWith(`..${path.sep}`) ||
    path.isAbsolute(relativePath)
  ) {
    return null;
  }

  try {
    const stats = await fs.promises.stat(candidate);
    if (stats.isFile()) return candidate;
    if (stats.isDirectory()) {
      const directoryIndex = path.join(candidate, "index.html");
      const indexStats = await fs.promises.stat(directoryIndex);
      if (indexStats.isFile()) return directoryIndex;
    }
  } catch {
    // A missing extensionless route is handled by the SPA fallback below.
  }

  if (path.extname(decodedPath) === "") {
    return path.join(DIST_DIR, "index.html");
  }

  return null;
}

const server = http.createServer(async (request, response) => {
  setSecurityHeaders(response);

  if (request.method !== "GET" && request.method !== "HEAD") {
    sendText(response, 405, "Method not allowed", { Allow: "GET, HEAD" });
    return;
  }

  let url;
  try {
    url = new URL(request.url || "/", "http://localhost");
    decodeURIComponent(url.pathname);
  } catch {
    sendText(response, 400, "Bad request");
    return;
  }

  if (url.pathname === "/health") {
    const body = JSON.stringify({ status: "ok" });
    response.writeHead(200, {
      "Cache-Control": "no-store",
      "Content-Length": Buffer.byteLength(body),
      "Content-Type": "application/json; charset=utf-8",
    });
    response.end(request.method === "HEAD" ? undefined : body);
    return;
  }

  let filePath;
  try {
    filePath = await resolveRequestFile(url.pathname);
  } catch {
    sendText(response, 400, "Bad request");
    return;
  }

  if (!filePath) {
    sendText(response, 404, "Not found");
    return;
  }

  let stats;
  try {
    stats = await fs.promises.stat(filePath);
  } catch {
    sendText(response, 404, "Not found");
    return;
  }

  const contentType =
    MIME_TYPES[path.extname(filePath).toLowerCase()] ||
    "application/octet-stream";
  const relativeFile = path
    .relative(DIST_DIR, filePath)
    .split(path.sep)
    .join("/");
  const cacheControl = relativeFile.startsWith("assets/")
    ? "public, max-age=31536000, immutable"
    : path.extname(filePath).toLowerCase() === ".html"
      ? "no-cache"
      : "public, max-age=3600";

  response.writeHead(200, {
    "Cache-Control": cacheControl,
    "Content-Length": stats.size,
    "Content-Type": contentType,
  });

  if (request.method === "HEAD") {
    response.end();
    return;
  }

  const stream = fs.createReadStream(filePath);
  stream.on("error", () => {
    if (!response.headersSent) {
      sendText(response, 500, "Internal server error");
    } else {
      response.destroy();
    }
  });
  stream.pipe(response);
});

const port = Number(process.env.PORT || 3000);
if (!Number.isInteger(port) || port < 1 || port > 65535) {
  throw new Error(`Invalid PORT value: ${process.env.PORT}`);
}

server.listen(port, "0.0.0.0", () => {
  console.log(`Harmony Clinic is listening on port ${port}`);
});

function shutdown() {
  server.close(() => process.exit(0));
}

process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
